from django.shortcuts import render
# Create your views here.
from django.contrib.auth import authenticate, login,logout
from rest_framework import serializers, status
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import UserSerializer
from rest_framework import generics
from rest_framework.response import Response
from .models import User
from .models import Message
from .serializers import MessageSerializer
from django.views import View
import json
from django.http import JsonResponse
from django.views import View
from rest_framework_simplejwt.tokens import RefreshToken
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from rest_framework.authentication import TokenAuthentication
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import authentication_classes, permission_classes
from datetime import datetime
from django.utils import timezone
from background_task import background
from .models import User
from datetime import timedelta,datetime
from chat_project import settings


@authentication_classes([])
@permission_classes([])
class UserLoginView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=username, password=password)
        if user:
            refresh_token = RefreshToken.for_user(user)
            access_token = refresh_token.access_token
            user.user_status = True
            user.token_generated_at = timezone.now()
            user.save()
            login(request, user)
            return JsonResponse({'message': 'Logged in successfully',
                             'refresh_token':str(refresh_token),
                             'access_token':str(access_token)})
        else:
            return JsonResponse({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)
        
def logout_view(request):
    if request.user.is_authenticated:
        # Set user_status to False when the user logs out
        request.user.user_status = False
        request.user.save()

        # Log the user out
        logout(request)
        return JsonResponse({'message': 'Logged out successfully'})
    else:
        return JsonResponse({'error': 'User not authenticated'}, status=401)
@authentication_classes([])
@permission_classes([])  
class UserRegistrationView(generics.CreateAPIView):
    serializer_class = UserSerializer

    def create(self, request, *args, **kwargs):
        user_id = request.data.get('id')  # Get the user ID from the request data

        if user_id:
            try:
                # Try to retrieve the user by ID
                existing_user = User.objects.get(id=user_id)

                # Update the existing user's data with the request data
                serializer = self.get_serializer(existing_user, data=request.data)
                serializer.is_valid(raise_exception=True)
                serializer.save()

                return Response(serializer.data, status=status.HTTP_200_OK)
            except User.DoesNotExist:
                pass

        # If the user does not exist or no ID provided, create a new one
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_201_CREATED)     
'''class UserRegistrationView(generics.CreateAPIView):
    serializer_class = UserSerializer
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    '''

@authentication_classes([])
@permission_classes([])
class OnlineUsersView(generics.ListAPIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    serializer_class = UserSerializer
    def get_queryset(self):
        return User.objects.filter(user_status=True)
    

class StartChatView(generics.CreateAPIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    def post(self, request):
        sender = self.request.user  # Assuming you're using JWT or session authentication
        recipient_username = request.data.get('recipient_username')

        try:
            recipient = User.objects.get(username=recipient_username)

            if recipient.user_status:
                # Recipient is online and available, you can initiate the chat
                return Response({'message': 'Chat initiated successfully'}, status=status.HTTP_200_OK)
            else:
                # Recipient is offline or unavailable
                return Response({'error': 'Recipient is offline'}, status=status.HTTP_400_BAD_REQUEST)

        except User.DoesNotExist:
            # Recipient username not found
            return Response({'error': 'Recipient not found'}, status=status.HTTP_404_NOT_FOUND)




class SuggestedFriendsView(View):
    def get(self, request, user_id):
        # Load the JSON data from the file
        json_file_path = 'data/your_json_file.json'  # Update with the actual path
        with open(json_file_path, 'r') as file:
            data = json.load(file)

        # Get the user data for the specified user_id
        user_data = data.get(str(user_id), None)

        if user_data is None:
            return JsonResponse({'error': 'User not found'}, status=404)

        # Define a function to calculate a similarity score with other users
        def calculate_similarity(user1, user2):
            # Implement your similarity score calculation logic here
            # This is based on the interest scores
            user1_interests = user1['interests']
            user2_interests = user2['interests']

            # Calculate the similarity score based on interest scores
            similarity_score = 0

            for interest, score1 in user1_interests.items():
                if interest in user2_interests:
                    score2 = user2_interests[interest]
                    score_diff = abs(score1 - score2)
                    normalized_score_diff = score_diff / 100.0  # Normalize to a 0-1 range
                    similarity_score += 1.0 - normalized_score_diff

            return similarity_score

        # Find the top 5 suggested friends based on similarity score
        suggested_friends = sorted(
            data.values(),
            key=lambda user: calculate_similarity(user_data, user),
            reverse=True
        )[:5]

        return JsonResponse({'suggested_friends': suggested_friends})
    


@background(schedule=16*settings.access_token_lifetime_in_min+5)  # Schedule the task to run every 16 minutes
def check_user_token_expiration():
    #print("in the task")
    current_time = timezone.now()
    users = User.objects.filter(user_status=True)

    for user in users:
        #token_expiration = user.token_generated_at + timedelta(minutes=settings.access_token_lifetime_in_min)
        if user.token_generated_at:
                # If token_generated_at is not None, calculate the expiration time based on it
            token_expiration = user.token_generated_at + timedelta(minutes=settings.access_token_lifetime_in_min)
        else:
            user.user_status = False
            print(user)
            print("status updated")
            user.save()

        if current_time > token_expiration:
            # Token has expired due to inactivity, set user_status to False
            user.user_status = False

check_user_token_expiration(repeat=16*settings.access_token_lifetime_in_min+5, repeat_until=None)
