from background_task import background
from .models import User
from datetime import timedelta,datetime
from chat_project import settings
from django.utils import timezone





@background(schedule=16)  # Schedule the task to run every 16 minutes
def check_user_token_expiration():
    current_time = timezone.now()
    users = User.objects.filter(user_status=True)

    for user in users:
        #token_expiration = user.token_generated_at + timedelta(minutes=settings.access_token_lifetime_in_min)
        if user.token_generated_at:
                # If token_generated_at is not None, calculate the expiration time based on it
            token_expiration = user.token_generated_at + timedelta(minutes=settings.access_token_lifetime_in_min)
        else:
            # If token_generated_at is None, set a default expiration time (e.g., 15 minutes from now)
            token_expiration = timezone.now() + timedelta(minutes=settings.access_token_lifetime_in_min)

        if current_time > token_expiration:
            # Token has expired due to inactivity, set user_status to False
            user.user_status = False
            user.save()

check_user_token_expiration(repeat=16, repeat_until=None)