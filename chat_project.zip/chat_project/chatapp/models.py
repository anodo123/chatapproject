from django.db import models
from datetime import datetime
import json
from django.db import models
from django.contrib.auth.models import AbstractUser
#from django.utils.translation import ugettext_lazy as _
from django.conf import settings
from django.contrib.sessions.models import Session
import jsonfield
from django.utils.timezone import now


class User(AbstractUser):
    email =models.CharField(max_length=256,null=True)
    user_status = models.BooleanField(default=False)
    age = models.PositiveIntegerField(null=True, blank=True)
    profile_picture = models.ImageField(upload_to='profile_pictures/', null=True, blank=True)
    interests = models.JSONField(default=dict)
    token_generated_at = models.DateTimeField(auto_now_add=False,blank = True,null = True)

    def __str__(self):
        return self.username



class Message(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_messages')
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='received_messages')
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)


    def __str__(self):
        return f"From {self.sender} to {self.recipient}: {self.content}"