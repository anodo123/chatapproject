# chatapp/serializers.py
from rest_framework import serializers
#from django.contrib.auth import get_user_model
from .models import User, Message




class UserSerializer(serializers.ModelSerializer):
    class Meta:
        interests = serializers.JSONField(default=dict)
        model = User
        fields = ('id', 'username', 'email', 'user_status', 'age', 'profile_picture', 'password','interests')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        # Create and return a new user instance with a hashed password
        password = validated_data.pop('password', None)
        user = User(**validated_data)
        if password:
            user.set_password(password)
        user.save()
        return user

class MessageSerializer(serializers.ModelSerializer):
    sender = UserSerializer(read_only=True)
    recipient = UserSerializer(read_only=True)

    class Meta:
        model = Message
        fields = ('id', 'sender', 'recipient', 'content', 'timestamp')