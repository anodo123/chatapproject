# chatapp/consumers.py
import json
import django
import os
from asgiref.sync import sync_to_async
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'chat_project.settings')
django.setup()
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import User, Message

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()

    async def disconnect(self, close_code):
        pass

    @sync_to_async
    def check_user_status(self, username):
        try:
            user = User.objects.get(username=username)
            return user.user_status
        except User.DoesNotExist:
            return False

    async def receive(self, text_data):
        data = json.loads(text_data)
        message = data.get('message')
        sender = data.get('sender')
        recipient_username = data.get('recipient')

        # Implement your logic to check if the recipient is online (user_status=True)
        #recipient_is_online = self.is_user_online(recipient_username)
        recipient_is_online = await self.check_user_status(recipient_username)
        print(recipient_is_online)
        if recipient_is_online:
            # Send the message to the recipient's channel
            await self.send_message_to_recipient(recipient_username, message,sender)
        else:
            await self.send_error_message("Recipient is offline or unavailable.")

    async def send_message_to_recipient(self, recipient_username, message,sender):
        # Implement logic to find the WebSocket channel of the recipient based on their username
        recipient_channel = self.get_recipient_channel(recipient_username)

        if recipient_channel:
            await self.channel_layer.send(
                recipient_channel,
                {
                    'type': 'chat.message',
                    'message': message,
                    'sender': sender
                },
            )
        else:
            await self.send_error_message("Recipient channel not found.")

    async def chat_message(self, event):
        message = event['message']
        sender = event['sender']

        # Send the message back to the WebSocket client
        await self.send(json.dumps({
            'message': message,
            'sender': sender,
        }))

    def is_user_online(self, username):
        status = False
        status = check_user_status(username)
        return status

    def get_recipient_channel(self, recipient_username):
        return f'user_{recipient_username}'

    async def send_error_message(self, error_message):
        await self.send(json.dumps({
            'error': error_message,
        }))
@sync_to_async
def check_user_status(username):
    try:
        user = User.objects.get(username=username)
        print(list(user.user_status))
        return user.user_status
    except User.DoesNotExist:
        print("issue occure")
        return False