from django.urls import path
from .views import UserRegistrationView,UserLoginView,OnlineUsersView,StartChatView,SuggestedFriendsView

urlpatterns = [
    path('register', UserRegistrationView.as_view(), name='user-register'),
    path('login', UserLoginView.as_view(), name='user-login'),
    path('online-users', OnlineUsersView.as_view(), name='online-users'),
    path('chat/start', StartChatView.as_view(), name='start-chat'),
    path('chat/suggested-friends/<int:user_id>/', SuggestedFriendsView.as_view(), name='suggested-friends'),
    
    # Define other API endpoints here
]